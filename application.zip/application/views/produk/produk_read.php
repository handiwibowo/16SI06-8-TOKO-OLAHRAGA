<?php
$this->load->view('template/head');
?>

<?php
$this->load->view('template/topbar');
$this->load->view('template/sidebar');
?>
<div class="container-fluid">

        <h2 style="margin-top:0px">Produk Read</h2>
        <table class="table">
	    <tr><td>Nama Produk</td><td><?php echo $nama_produk; ?></td></tr>
	    <tr><td>Harga Produk</td><td><?php echo $harga_produk; ?></td></tr>
	    <tr><td>Kategori Produk</td><td><?php echo $kategori_produk; ?></td></tr>
	    <tr><td>Foto Produk</td><td><?php echo $foto_produk; ?></td></tr>
	    <tr><td>Ukuran</td><td><?php echo $ukuran; ?></td></tr>
	    <tr><td>Berat</td><td><?php echo $berat; ?></td></tr>
	    <tr><td>Deskripsi Produk</td><td><?php echo $deskripsi_produk; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('produk') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        

    </div>
<?php
$this->load->view('template/js');
?>

<?php
$this->load->view('template/foot');
?>