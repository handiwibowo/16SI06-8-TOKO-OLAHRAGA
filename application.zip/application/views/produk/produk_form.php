<?php
$this->load->view('template/head');
?>

<?php
$this->load->view('template/topbar');
$this->load->view('template/sidebar');
?>
<div class="container-fluid">

        <h2 style="margin-top:0px">Produk <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Nama Produk <?php echo form_error('nama_produk') ?></label>
            <input type="text" class="form-control" name="nama_produk" id="nama_produk" placeholder="Nama Produk" value="<?php echo $nama_produk; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Harga Produk <?php echo form_error('harga_produk') ?></label>
            <input type="text" class="form-control" name="harga_produk" id="harga_produk" placeholder="Harga Produk" value="<?php echo $harga_produk; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Kategori Produk <?php echo form_error('kategori_produk') ?></label>
            <input type="text" class="form-control" name="kategori_produk" id="kategori_produk" placeholder="Kategori Produk" value="<?php echo $kategori_produk; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Foto Produk <?php echo form_error('foto_produk') ?></label>
            <input type="file" class="form-control" name="foto_produk" id="foto_produk" placeholder="Foto Produk" value="<?php echo $foto_produk; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Ukuran <?php echo form_error('ukuran') ?></label>
            <input type="text" class="form-control" name="ukuran" id="ukuran" placeholder="Ukuran" value="<?php echo $ukuran; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Berat <?php echo form_error('berat') ?></label>
            <input type="text" class="form-control" name="berat" id="berat" placeholder="Berat" value="<?php echo $berat; ?>" />
        </div>
	    <div class="form-group">
            <label for="deskripsi_produk">Deskripsi Produk <?php echo form_error('deskripsi_produk') ?></label>
            <textarea class="form-control" rows="3" name="deskripsi_produk" id="deskripsi_produk" placeholder="Deskripsi Produk"><?php echo $deskripsi_produk; ?></textarea>
        </div>
	    <input type="hidden" name="id_produk" value="<?php echo $id_produk; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('produk') ?>" class="btn btn-default">Cancel</a>
	</form>

   </div>
<?php
$this->load->view('template/js');
?>

<?php
$this->load->view('template/foot');
?>