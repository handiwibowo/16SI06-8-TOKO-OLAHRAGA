<?php
$this->load->view('template/head');
?>

<?php
$this->load->view('template/topbar');
$this->load->view('template/sidebar');
?>
<div class="container-fluid">

        <h2 style="margin-top:0px">Pelanggan Read</h2>
        <table class="table">
	    <tr><td>Nama Pelanggan</td><td><?php echo $nama_pelanggan; ?></td></tr>
	    <tr><td>Email Pelanggan</td><td><?php echo $email_pelanggan; ?></td></tr>
	    <tr><td>Telepon Pelanggan</td><td><?php echo $telepon_pelanggan; ?></td></tr>
	    <tr><td>Alamat Pelanggan</td><td><?php echo $alamat_pelanggan; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('pelanggan') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
    
</div>
<?php
$this->load->view('template/js');
?>

<?php
$this->load->view('template/foot');
?>