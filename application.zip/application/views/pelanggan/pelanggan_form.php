<?php
$this->load->view('template/head');
?>

<?php
$this->load->view('template/topbar');
$this->load->view('template/sidebar');
?>
<div class="container-fluid">

        <h2 style="margin-top:0px">Pelanggan <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Nama Pelanggan <?php echo form_error('nama_pelanggan') ?></label>
            <input type="text" class="form-control" name="nama_pelanggan" id="nama_pelanggan" placeholder="Nama Pelanggan" value="<?php echo $nama_pelanggan; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Email Pelanggan <?php echo form_error('email_pelanggan') ?></label>
            <input type="text" class="form-control" name="email_pelanggan" id="email_pelanggan" placeholder="Email Pelanggan" value="<?php echo $email_pelanggan; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Telepon Pelanggan <?php echo form_error('telepon_pelanggan') ?></label>
            <input type="text" class="form-control" name="telepon_pelanggan" id="telepon_pelanggan" placeholder="Telepon Pelanggan" value="<?php echo $telepon_pelanggan; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Alamat Pelanggan <?php echo form_error('alamat_pelanggan') ?></label>
            <input type="text" class="form-control" name="alamat_pelanggan" id="alamat_pelanggan" placeholder="Alamat Pelanggan" value="<?php echo $alamat_pelanggan; ?>" />
        </div>
	    <input type="hidden" name="id_pelanggan" value="<?php echo $id_pelanggan; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('pelanggan') ?>" class="btn btn-default">Cancel</a>
	</form>

</div>
<?php
$this->load->view('template/js');
?>

<?php
$this->load->view('template/foot');
?>