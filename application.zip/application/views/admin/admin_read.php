<?php
$this->load->view('template/head');
?>

<?php
$this->load->view('template/topbar');
$this->load->view('template/sidebar');
?>

        <h2 style="margin-top:0px">Admin Read</h2>
        <table class="table">
	    <tr><td>Nama Admin</td><td><?php echo $nama_admin; ?></td></tr>
	    <tr><td>Email Admin</td><td><?php echo $email_admin; ?></td></tr>
	    <tr><td>Pass Admin</td><td><?php echo $pass_admin; ?></td></tr>
	    <tr><td>Telp Admin</td><td><?php echo $telp_admin; ?></td></tr>
	    <tr><td>Alamat Admin</td><td><?php echo $alamat_admin; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('admin') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
<?php
$this->load->view('template/js');
?>

<?php
$this->load->view('template/foot');
?>