<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Admin extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Admin_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'admin/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'admin/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'admin/index.html';
            $config['first_url'] = base_url() . 'admin/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Admin_model->total_rows($q);
        $admin = $this->Admin_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'admin_data' => $admin,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('admin/admin_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Admin_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_admin' => $row->id_admin,
		'nama_admin' => $row->nama_admin,
		'email_admin' => $row->email_admin,
		'pass_admin' => $row->pass_admin,
		'telp_admin' => $row->telp_admin,
		'alamat_admin' => $row->alamat_admin,
	    );
            $this->load->view('admin/admin_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('admin'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('admin/create_action'),
	    'id_admin' => set_value('id_admin'),
	    'nama_admin' => set_value('nama_admin'),
	    'email_admin' => set_value('email_admin'),
	    'pass_admin' => set_value('pass_admin'),
	    'telp_admin' => set_value('telp_admin'),
	    'alamat_admin' => set_value('alamat_admin'),
	);
        $this->load->view('admin/admin_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'nama_admin' => $this->input->post('nama_admin',TRUE),
		'email_admin' => $this->input->post('email_admin',TRUE),
		'pass_admin' => $this->input->post('pass_admin',TRUE),
		'telp_admin' => $this->input->post('telp_admin',TRUE),
		'alamat_admin' => $this->input->post('alamat_admin',TRUE),
	    );

            $this->Admin_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('admin'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Admin_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('admin/update_action'),
		'id_admin' => set_value('id_admin', $row->id_admin),
		'nama_admin' => set_value('nama_admin', $row->nama_admin),
		'email_admin' => set_value('email_admin', $row->email_admin),
		'pass_admin' => set_value('pass_admin', $row->pass_admin),
		'telp_admin' => set_value('telp_admin', $row->telp_admin),
		'alamat_admin' => set_value('alamat_admin', $row->alamat_admin),
	    );
            $this->load->view('admin/admin_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('admin'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_admin', TRUE));
        } else {
            $data = array(
		'nama_admin' => $this->input->post('nama_admin',TRUE),
		'email_admin' => $this->input->post('email_admin',TRUE),
		'pass_admin' => $this->input->post('pass_admin',TRUE),
		'telp_admin' => $this->input->post('telp_admin',TRUE),
		'alamat_admin' => $this->input->post('alamat_admin',TRUE),
	    );

            $this->Admin_model->update($this->input->post('id_admin', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('admin'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Admin_model->get_by_id($id);

        if ($row) {
            $this->Admin_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('admin'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('admin'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nama_admin', 'nama admin', 'trim|required');
	$this->form_validation->set_rules('email_admin', 'email admin', 'trim|required');
	$this->form_validation->set_rules('pass_admin', 'pass admin', 'trim|required');
	$this->form_validation->set_rules('telp_admin', 'telp admin', 'trim|required');
	$this->form_validation->set_rules('alamat_admin', 'alamat admin', 'trim|required');

	$this->form_validation->set_rules('id_admin', 'id_admin', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Admin.php */
/* Location: ./application/controllers/Admin.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-12-25 16:26:55 */
/* http://harviacode.com */